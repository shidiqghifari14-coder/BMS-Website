# Evaluasi sebelum dan sesudah perbaikan

## Sebelum

CSV hanya snapshot sel; polling 1 Hz; temperatur 20 sensor simulasi tanpa mapping modul; seluruh sumber diperlakukan sebagai satu timestamp pack; logo dan ikon generik; belum ada panduan penggunaan atau adapter log STM.

## Sesudah

| Area | Perubahan | Batas yang masih ada |
| --- | --- | --- |
| Identitas | Dua aset logo resmi dipasang tanpa mengubah file asli. Navigasi, warna tim, tipografi, SOC dan label disederhanakan; ikon dekoratif dan sparkline palsu dihapus. | Penilaian estetika tetap subjektif. |
| Temperatur | 10 slot × 24 kanal; mapping 1A–4A/1B–4B mengikuti source STM. °C langsung sesuai konfirmasi pengguna. | Slot 9/10 belum punya mapping CAN; firmware lama tidak memberi freshness per sensor. |
| UART STM | Parser menerima siklus log lengkap dan fragmentasi USB; 48 tegangan lokal disimpan terpisah; tanda arus asli dipertahankan. | Belum diuji dengan kabel/hardware nyata; USB browser memakai shim dalam tes. |
| Logging | Worker terpisah, IndexedDB bertahap, CSV time series, sequence/dedup, bagian 16 MiB, recovery setelah reload. | Batas 512 MiB/sesi; browser/background/storage bukan pengganti logger embedded yang selalu aktif. |
| Laju | Akuisisi terpisah dari layar 4 Hz, NDJSON stream dan polling/batch; demo 20/50/100 target sampel/s. | Tidak menaikkan laju akuisisi STM atau menciptakan sampel saat hardware lambat. |
| Data yang hilang | Tetap null/unknown; pack voltage/daya membutuhkan 140 sel; tidak mengisi slot cadangan dengan nol palsu. | Firmware yang mencetak nol inisialisasi tidak bisa dibedakan dari 0 °C tanpa valid mask. |
| Panduan | Menu Panduan dan dokumen penggunaan mencakup USB, gateway, mapping, recording dan export. | Dukungan Web Serial bergantung browser dan izin pengguna. |
| Firmware | Source diaudit dan berhasil direbuild dengan path linker lokal yang diperbaiki pada salinan audit. | Bug logika firmware yang didokumentasikan belum diterapkan/diflash. |

## Bukti verifikasi

- Unit test memeriksa validasi 140 sel, null/stale, parser UART terfragmentasi, delapan modul 24 kanal, reservasi dua modul, mapping opsional, tanda arus, duplicate/out-of-order dan skema CSV.
- Server uji HTTP NDJSON menghasilkan **600 frame dengan timestamp berjarak 10 ms (100 Hz)**. Semua **600 baris** tersimpan, sequence berurutan tanpa duplikat, lalu berhasil diunduh setelah reload.
- Pengujian ini adalah data sintetis lewat transport HTTP sungguhan; bukan pengukuran laju atau kalibrasi STM/TSEB nyata. Server boleh mengirim beberapa frame bersama sesuai scheduler, namun timestamp sumber dan masing-masing frame tetap dipertahankan.
- Smoke test memeriksa 7 view pada 390/768/1280/1512 px tanpa overflow halaman dan tanpa console/page error.
- Shim Web Serial memeriksa opsi 115200/8N1, parser satu siklus, nilai 4B T24, konvensi arus dan tidak adanya mapping pack otomatis. Bukan pengujian port serial hardware.
- Rebuild firmware dengan GNU STM32 13.3.rel1 berhasil setelah mengganti path linker pada audit.makefile; source C/H tidak diubah. Detail dan warning pada `AUDIT-STM32.md`.

## Urutan pekerjaan hardware berikutnya

1. Koreksi dan uji batas array CB, min/max voltage, indeks rata-rata modul serta DLC CAN.
2. Tambahkan valid mask, timestamp, timeout dan overtemperature fault di firmware.
3. Tetapkan mapping lengkap 140 sel dan modul temperatur 9/10 bersama VCU/TSEB.
4. Pisahkan akuisisi/proteksi dari printf; sediakan telemetry bertimestamp/sequence dan logger gateway bila diperlukan.
5. Integrasikan estimator SOC/SOH dengan kapasitas dan arus yang sudah dikalibrasi; lakukan uji bench sebelum pack penuh.
