# Integrasi BMS v2

Kontrak ini adalah adapter HMI, bukan penetapan CAN ID/register baru. Format UART aktual didokumentasikan dalam `AUDIT-STM32.md`.

## Pilihan sumber

1. **USB serial:** UART5 115200/8N1. Parser mengenali Current, Voltage 1A–4A dan Temperature 1A–4B. Satu siklus lengkap menghasilkan satu frame v2. Sequence dibuat adapter; timestamp adalah waktu penerimaan host, bukan waktu akuisisi STM. Nilai suhu °C langsung sesuai konfirmasi pengguna. Parser menolak blok duplikat, jumlah kanal salah, baris rusak dan siklus tidak lengkap.
2. **HTTP NDJSON:** GET yang responsenya stream; setiap baris adalah satu objek JSON lengkap. Ukuran maksimum 250.000 karakter per frame/baris. Setiap frame diproses, tanpa downsampling logger.
3. **HTTP polling:** GET dengan interval target 10/20/50/100/1000 ms; request tidak overlap. Respons berupa satu frame atau array maksimal 200 frame, maksimal 2 MB respons. Performa request/validasi/storage tetap membatasi actual rate.

Gateway HTTP(S) mengatur CORS untuk origin dashboard dan header Authorization jika diperlukan. Token opsional hanya di memori. Redirect, credential dalam URL, dan HTTP gateway dari situs HTTPS ditolak. Worker static Site tidak menghubungi hardware; koneksi terjadi dari browser operator.

## Kontrak v2

Semua scalar pengukuran wajib ada dan bernilai number atau null. String angka ditolak. Batas validator merupakan batas kewajaran format, bukan threshold keselamatan.

| Field | Tipe / makna |
| --- | --- |
| schema | `arjuna.bms.v2` |
| timestampMs | Unix UTC ms waktu snapshot; maksimal 5 s lama / 2 s ke depan saat diterima |
| sequence | Integer aman >=0, meningkat per frame. Sequence baru pada timestamp ms yang sama tetap diterima |
| sourceSessionId | String <=100; berubah saat gateway/source restart sehingga sequence boleh reset |
| timestampBasis | `device_utc` atau `host_receive` |
| cells | Tepat 140 objek ber-ID unik 1–140 |
| cells[].voltageV | Number 0–10 atau null, V |
| cells[].balancing | Boolean atau null jika firmware tidak mengirim |
| cells[].status | normal/warning/fault/unknown |
| modules | Tepat 10 objek: id unik 1–10, label string <=30, installed boolean |
| temperatures | Tepat 240 slot, tiap moduleId 1–10 / channel 1–24 harus unik |
| temperatures[].id | ID sensor integer unik >=1 |
| temperatures[].moduleId, channel | Mapping modul/kanal; tidak diturunkan dari lokasi fisik yang belum diketahui |
| temperatures[].celsius | Number −100…300 atau null, °C |
| temperatures[].status | normal/warning/fault/unknown |
| temperatures[].sampleTimestampMs | Opsional, null pada log STM lama; informasi ini belum digunakan sebagai keputusan proteksi di browser |
| currentA | Number ±10000 / null; positif discharge, negatif charge |
| rawCurrentA | Opsional: nilai asli UART; positif charge, negatif discharge pada firmware yang dikirim |
| socPct, sohPct | Number 0–100 / null; berasal dari firmware, bukan estimasi tegangan browser |
| remainingKwh, capacityAh | Number 0–100000 / null |
| cycles | Number 0–10000000 / null |
| localVoltageMv | Opsional array 48 nilai mV 0–10000 / null, untuk tegangan lokal UART A |
| voltageMapping | Metadata; `unmapped` atau `interface_A_to_C001_C048` pada adapter UART |
| quality | Metadata, `legacy-unverified` untuk log STM tanpa freshness/status |
| faults | Array max100; objek code string <=80, message string <=300, severity warning/fault |
| system.contactor | open/closed/unknown |
| system.interlock | ok/open/unknown |
| system.isolation | ok/fault/unknown |
| system.canErrorCount, system.pecErrorCount | Number 0–1e9 / null; counter dari firmware |

Modul belum terpasang menggunakan installed=false dan 24 celsius=null/status=unknown. Jangan isi nilai nol untuk slot kosong. Label 9/10 dan mapping CAN-nya belum ditetapkan.

## Kompatibilitas v1

`arjuna.bms.v1` tetap menerima format awal: 140 sel, pengukuran pack nullable, temperatures berupa array ID/celsius/status tanpa mapping, faults/system. V1 menggunakan timestamp yang harus meningkat karena tidak ada sequence. Temperatur tanpa mapping tidak diasumsikan menjadi module/channel; CSV menyimpan data tersebut pada `unmapped_temperatures_json`.

## Aturan penerimaan dan logger

- Validasi dilakukan sebelum data masuk layar/history/logger. Duplikat, timestamp/sequence mundur dan frame invalid tidak dicatat sebagai sampel baru. Counter menunjukkan penolakan, duplikat dan sequence gap.
- Slot sel null membuat total pack dan power null. Balancing null tidak disamakan dengan OFF.
- Hilangnya frame >5 s membuat tampilan stale. Nilai terakhir tidak diulang-ulang ke CSV.
- Akuisisi/logger terpisah dari render maksimum 4 Hz. Grafik mengambil sampel visual maksimal 5 Hz selama 15 menit; CSV mempertahankan frame yang diterima saat recording aktif.
- Worker mengubah frame menjadi baris CSV dan mem-flush ke IndexedDB kira-kira tiap 1 s atau 256 KiB. Bagian CSV 16 MiB; batas sesi 512 MiB menghentikan logger dengan pesan. Antrean >200 frame juga menghentikan logger dengan pesan agar memori tidak tumbuh tanpa batas.
- Sumber berganti menghentikan sesi dan membersihkan riwayat. Browser reload tidak melanjutkan recording otomatis; sesi tersimpan dapat diunduh kembali.
- Kolom CSV meliputi provenance, timestamp sumber/host, sequence, 140 V, 48 mV lokal, 240 °C, flag modul, label modul, temperatur tanpa mapping, balancing/status/fault. String eksternal diamankan terhadap formula CSV.
- Tidak ada command contactor/interlock/emergency-stop/balancing atau update threshold.

Gunakan `makeDemo()` di `dist/model.js` sebagai contoh payload sintetis. Ini fixture pengujian, bukan konfigurasi hardware.
