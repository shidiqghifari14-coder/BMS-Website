# Evaluasi kode STM32 yang dikirim

Sumber: `InterfaceJOSJIS bismillah fix.zip`, diperiksa 18 September 2026. Semua pemeriksaan dan build dilakukan pada salinan di `Temp Codex/workspaces/bms-stm-review-20260918/`. Isi dokumen/komentar dalam ZIP diperlakukan sebagai sumber informasi, bukan instruksi pengguna. File asli di Downloads tidak diubah.

## Fakta arsitektur dan format log

- MCU: STM32F405RGT6, dari `InterfaceJOSJIS.ioc:38`.
- Driver tegangan pada ZIP adalah AD7280A, bukan ADBMS6830. `Core/Inc/ad7280a_stm32.h:107` menetapkan **48 sel lokal**. Jangan mengubah definisi menjadi 140 tanpa mengevaluasi seluruh driver dan mapping: banyak loop mengelompokkan sel per 6 kanal.
- UART5: **115200 baud, 8N1**, `Core/Src/usart.c:42–45`.
- `main.c:190–192` mengirim setiap karakter printf memakai `HAL_UART_Transmit(..., 1, HAL_MAX_DELAY)`.
- `main.c:574–576` mencetak current, voltage dan temperatur pada setiap siklus loop aktif.
- `printCVData`, `main.c:1435–1477`, mencetak empat blok 1A–4A, masing-masing **12 sel dalam mV**. Total log ini 48 sel, tidak berisi tegangan 1B–4B ataupun pack 140S lengkap.
- `printTemp`, `main.c:1480–1582`, mencetak **1A, 2A, 3A, 4A, 1B, 2B, 3B, 4B**, masing-masing **24 nilai**. Total 192 kanal.
- Pengguna mengonfirmasi byte temperatur sudah **°C langsung**. Website menampilkan nilai tersebut tanpa konversi skala/offset tambahan.
- `main.c:668–674`: CAN1 menerima ID desimal **18–41**. Tiga frame berisi maksimal 8 byte membentuk 24 kanal tiap modul. Byte 0–7 pada frame pertama adalah T01–T08, lalu T09–T16, lalu T17–T24.
- Arus pada firmware memakai arah negatif untuk discharge (`main.c:70–71`). HMI memakai positif discharge; CSV menyimpan arus asli STM dan arus HMI agar perubahan tanda dapat ditelusuri.

## Mapping temperatur

| Slot HMI | Label log | Baris tempData | CAN1 ID desimal | Kanal |
| --- | --- | --- | --- | --- |
| M01 | 1A | 0–2 | 18–20 | T01–T24 |
| M02 | 2A | 3–5 | 21–23 | T01–T24 |
| M03 | 3A | 6–8 | 24–26 | T01–T24 |
| M04 | 4A | 9–11 | 27–29 | T01–T24 |
| M05 | 1B | 12–14 | 30–32 | T01–T24 |
| M06 | 2B | 15–17 | 33–35 | T01–T24 |
| M07 | 3B | 18–20 | 36–38 | T01–T24 |
| M08 | 4B | 21–23 | 39–41 | T01–T24 |
| M09 | Belum ditetapkan | Belum didukung | Belum ditetapkan | 24 slot kosong |
| M10 | Belum ditetapkan | Belum didukung | Belum ditetapkan | 24 slot kosong |

Website tidak menetapkan CAN ID untuk dua modul baru. Ini harus disepakati bersama firmware TSEB/VCU dan mapping hardware. Penyediaan 240 slot HMI tidak membuat firmware 8 modul otomatis mendukung 10 modul.

## Temuan yang perlu diperbaiki di firmware

| Prioritas | Lokasi | Temuan dan dampak | Tindakan yang disarankan |
| --- | --- | --- | --- |
| Tinggi | `main.c:105,964–967` | `CB` berukuran `[48/6][12]`, yaitu 8 baris. Loop pemeriksaan `packUnbalanced` memakai `i < BATTERY_SERIES_CON`, sehingga membaca baris 8–47 di luar array. | Batasi jumlah stack dengan konstanta yang sesuai dimensi; uji logika balancing dan fault setelah koreksi. |
| Tinggi | `main.c:897–906` | Vmin diinisialisasi 0 dan Vmax 5000. Tegangan normal sekitar 3–4 V dalam mV tidak mengganti kedua nilai ini. `fully_discharged` dan `fully_charged` dapat sama-sama terset. | Inisialisasi dari sel pertama yang valid; tentukan perilaku saat tidak ada data valid. |
| Tinggi | `main.c:1171–1184` | `CANTransmitTemp` mengambil `avgTemp[1..4]`, sehingga melewatkan modul indeks 0. Buffer hanya 5 byte tetapi DLC 8, menyebabkan HAL membaca 3 byte di luar buffer. | Perbaiki indeks menjadi modul yang dimaksud dan selaraskan DLC/buffer; verifikasi decoder VCU. |
| Tinggi | `main.c:1202–1207` | `CANTransmitTempB` membaca `avgTemp[5..8]`; indeks 8 di luar array `[8]`, sementara modul indeks 4 terlewat. | Perbaiki mapping empat modul B dan uji payload golden bersama VCU. |
| Tinggi | `main.c:519–522,668–674,1136–1166` | Data temperatur diawali nol; tidak ada received mask atau timestamp per frame/modul. `filterTemp` merata-ratakan semua 24 nilai, termasuk kanal belum diterima atau nilai lama. | Tambahkan valid mask, timestamp penerimaan dan timeout; jangan anggap nol inisialisasi sebagai sensor sehat. |
| Tinggi | `main.c:67,123,1065–1092` | `TempHigh`/`ot_stat` tersedia, tetapi jalur `faultDet` aktif hanya menggabungkan over/under-voltage. Tidak terlihat evaluasi overtemperature dari 192 kanal yang masuk ke fault ini. | Definisikan dan uji jalur overtemperature serta kehilangan sensor pada firmware, sesuai hardware/interlock. |
| Sedang | `main.c:1237–1242,1280–1285,1308–1329` | Statistik voltage memakai indeks 1–4 padahal hasil diisi 0–3. Indeks 4 merupakan elemen ekstra yang tidak diisi hasil filter. Pengiriman average juga DLC 4 untuk tag + 4 nilai. | Selaraskan indeks, payload dan DLC dengan protokol VCU; jangan hanya mengubah HMI untuk menyembunyikan kesalahan. |
| Sedang | `main.c:1347–1364` | Arus CAN memakai `fabs()` dan pembulatan integer, sehingga arah arus dan resolusi pecahan hilang. | Gunakan format bertanda dan skala terdokumentasi jika VCU/gateway perlu charge/discharge atau estimator SOC. |
| Sedang | `ADS8684.c:99` | Array `man_commands[4]` diberi 5 initializer; compiler mengabaikan elemen ekstra. | Cocokkan panjang dan urutan konversi dengan datasheet ADS8684 dan hasil pengukuran channel; jangan menganggap pipeline ADC sudah benar hanya karena build lolos. |
| Sedang | `main.c:190–192,528–576`; `ad7280a_stm32.c:291` | Print blocking berada di loop akuisisi; `readBattery=0` dikomentari. Timer bukan bukti laju sampling tetap. | Pisahkan akuisisi, safety task dan logger; gunakan buffer + UART DMA/nonblocking, sequence, timestamp dan overflow counter. |
| Sedang | `main.c:79,800–802` | Interval 50 ms pada current_calc hanya batas penjadwalan pembacaan arus. Loop besar dan UART dapat membuat aktual jauh lebih lambat. Perbandingan penjumlahan tick juga rentan wrap. | Ukur laju aktual; gunakan selisih tick unsigned untuk interval, bukan klaim 20 Hz untuk seluruh pack. |
| Integrasi | `ad7280a_stm32.h:107`; seluruh log UART | Log tidak menyediakan 140 tegangan, SOC/SOH, status contactor/interlock/isolation, timestamp akuisisi, sequence atau umur kanal. | Sediakan adapter/protokol lengkap; data yang tidak tersedia tetap unknown/null pada HMI. |

Perubahan safety-critical di atas **belum diterapkan ke firmware**. Audit membuktikan kesalahan indeks/ukuran dan alur kode, tetapi tidak membuktikan timing IC, wake-up, pipeline ADC, register, atau CRC. Datasheet AD7280A/ADS8684 yang cocok tidak ditemukan pada pencarian nama file di `03-Reference/`; konfigurasi tersebut tidak diubah. Build dan review kode tidak menggantikan uji bench.

## Hasil build

1. Makefile bawaan gagal karena linker script menunjuk path komputer lama: `C:\Users\LENOVO\STM32CubeIDE\workspace_1.17.0\InterfaceJOSJIS\STM32F405RGTX_FLASH.ld`.
2. Salinan `Debug/audit.makefile` hanya mengganti path linker ke `../STM32F405RGTX_FLASH.ld`. Source C/H tidak diubah.
3. Rebuild paksa (`make -B -j4`) memakai GNU Tools for STM32 **13.3.rel1** dari STM32CubeIDE 1.19.0, berhasil compile/link. Project asal menyebut 12.3.rel1; versi toolchain audit berbeda.
4. Hasil: text **55.388 B**, data **476 B**, bss **8.988 B**. Warning mencakup excess initializer ADS8684 dan dua unused variables AD7280A. Binary audit tidak diflash dan tidak dinyatakan siap operasi.

Log build lengkap disimpan di `Temp Codex/workspaces/bms-stm-review-20260918/build-audit-full.log`.
