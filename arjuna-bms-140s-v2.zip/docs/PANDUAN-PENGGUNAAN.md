# Panduan BMS ARJUNA v2

Panduan interaktif yang sama tersedia di menu **Panduan** pada website.

## Menjalankan lokal

Ekstrak paket, buka terminal di folder project, lalu:

```powershell
node tools/serve.mjs
```

Buka `http://127.0.0.1:8790`. Node.js 20+ dibutuhkan untuk server lokal. Situs yang sudah dipublikasikan dapat dibuka langsung tanpa menjalankan server ini.

## Menghubungkan STM sekarang

1. Hubungkan UART5 STM32 ke USB–UART sesuai wiring dan level tegangan hardware.
2. Buka website di Chrome/Edge desktop. Tutup serial monitor lain yang memegang COM port.
3. Tekan **Koneksi**, pilih **USB serial**, lalu **Hubungkan** dan pilih port. Aplikasi menggunakan **115200 baud, 8N1**.
4. Tunggu satu siklus Current + Voltage 1A–4A + Temperature 1A–4B. Parser menerima baris yang terpecah menjadi beberapa paket USB dan menolak siklus tidak lengkap.
5. Cek label sumber dan laju aktual. Bila browser dalam aplikasi belum menyediakan Web Serial, buka URL di Chrome/Edge eksternal.

## Pemetaan data

- Suhu berasal dari log STM, °C langsung. Delapan modul mempunyai 24 kanal per modul. Slot 9–10 kosong sampai data dan mapping firmware tersedia.
- Tanpa centang mapping pada dialog koneksi, 48 tegangan lokal A hanya masuk kolom UART CSV; slot pack tidak diasumsikan.
- Centang **Tampilkan 48 sel lokal interface A pada C001–C048** hanya jika sesuai wiring. Slot C049–C140 tetap kosong.
- Tegangan pack/daya tidak ditampilkan sebelum 140 sel lengkap. SOC/SOH dan status sistem yang tidak ada pada log tetap unknown/“—”.
- Arus STM negatif discharge dikonversi ke konvensi HMI positif discharge. CSV menyimpan kedua versi.

## Merekam CSV time series

1. Buka **Perekaman**, beri nama sesi, tekan **Mulai rekam**.
2. Lihat jumlah baris yang sudah tersimpan, laju aktual, antrean dan indikator kualitas data.
3. Tekan **Hentikan & simpan** sebelum menutup tab atau berpindah sumber.
4. Pilih sesi dan bagian CSV, lalu **Unduh rekaman CSV**. Jika terdapat beberapa bagian, unduh seluruhnya.

Satu frame baru menjadi satu baris berisi **140 slot tegangan + 48 kanal lokal UART + 240 slot temperatur**, current, SOC/SOH, status dan metadata sumber. Sampel duplikat atau out-of-order tidak digandakan; sequence gap ditampilkan jika sumber mendukung sequence.

CSV dibagi setiap 16 MiB dan setiap bagian memiliki header. Batas sesi 512 MiB menghentikan perekaman dengan pemberitahuan; mulai sesi baru untuk melanjutkan. Data disimpan pada IndexedDB browser/origin yang sama. Rekaman yang sudah tersimpan dapat diambil kembali setelah reload; tail yang belum diflush dapat hilang jika browser ditutup paksa. Cadangkan CSV karena storage dapat dibersihkan atau penuh.

Tombol **Snapshot sel** di kanan atas hanya menyimpan satu keadaan 140 sel; bukan rekaman waktu.

## Laju tinggi

- Layar diperbarui maksimum 4 Hz secara terpisah dari akuisisi/logger.
- Generator demo memiliki target 20/50/100 sampel/s. Angka aktual mengikuti scheduler browser.
- HTTP NDJSON stream menyimpan setiap frame baru dari gateway; gunakan newline setelah setiap JSON.
- Polling mendukung interval target 10–1000 ms dan batch maksimal 200 frame. Tidak pernah membuat sampel baru dari data lama untuk memenuhi target Hz.
- Data STM saat ini dibatasi printf blocking dan bandwidth UART. Laju arus 50 ms di kode bukan jaminan seluruh paket berjalan 20 Hz.
- Saat tab di latar belakang atau laptop sleep, browser dapat berhenti menerima/merekam. Untuk logging kendaraan tanpa operator/browser aktif, letakkan logger utama pada firmware/gateway.

## Status yang perlu dipahami

- **DEMO:** semua nilai adalah simulasi.
- **STALE:** lebih dari 5 detik tanpa frame baru; data lama ditahan untuk inspeksi, tidak diulang ke CSV sebagai sampel baru.
- **UNKNOWN:** firmware tidak memberi status atau validitas yang diperlukan.
- **RESERVED:** slot modul tersedia di HMI, tetapi belum terpasang/dipetakan.
- **LOG STM:** nilai mengikuti log lama; firmware belum memberi umur data per sensor. Nol dapat berasal dari inisialisasi, bukan suhu nyata.

Website tidak mengirim perintah contactor, emergency stop, balancing atau perubahan batas proteksi. Lihat `AUDIT-STM32.md` untuk temuan firmware yang masih perlu diperbaiki dan diuji.
