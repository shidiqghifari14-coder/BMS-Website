# Verifikasi v2

Jalankan `node tools/check.mjs`, unit test pada `tests/*.test.mjs`, dan browser smoke test `node tests/smoke.mjs` dengan server lokal aktif. Hasil rinci ada pada `test-results/smoke-v2-report.json`.

- 12 unit test lolos, termasuk validasi 140 sel, data null, malformed frame, stale/future time dan status.
- Parser byte UART terfragmentasi, 4×12 tegangan lokal, 8×24 temperatur, 2 modul kosong, mapping opt-in, current sign.
- Sequence sama/mundur/gap, same-ms distinct sample, CSV header dan nilai metadata.
- Real HTTP stream dari server uji: 600 frame bertimestamp 10 ms, 600 row unik dengan 466 kolom disimpan/diunduh; data masih tersedia setelah reload.
- UI Web Serial melalui shim: opsi 115200/8N1, log lengkap, nilai 4B T24, unknown SOC dan pack mapping.
- Logo asli, 140-cell inspector/search/filter, thermal fault, stale/recovery, logging controls, guide.
- Semua 7 view di 390/768/1280/1512 px; page/console error ditangkap.

HMI tidak memerlukan bundler. Tidak ada library/asset CDN. Tes stream adalah sumber sintetis pada transport HTTP nyata. Tes USB memakai API shim, bukan kabel/perangkat. Native WebMCP tidak tersedia di browser QA. Belum ada uji endurance berjam-jam, quota exhaustion, background browser atau 512 MiB; batas itu proteksi implementasi dan belum merupakan benchmark kapasitas.

Source STM32 berhasil rebuild dengan GCC STM32 13.3.rel1 setelah path linker pada audit.makefile disesuaikan. Seluruh 128 file C/H dicocokkan byte per byte dengan ZIP asli dan tidak berubah. Kedua logo juga identik dengan aset pengguna. Source firmware tidak diubah/diflash. Lihat `AUDIT-STM32.md` untuk warning dan masalah logika yang tetap ada.
