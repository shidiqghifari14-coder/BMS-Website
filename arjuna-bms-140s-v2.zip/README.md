# ARJUNA BMS v2 — 140S / 10 modul temperatur

HMI untuk monitoring, koneksi log STM dan perekaman CSV. Source berada di `Temp Codex/workspaces/arjuna-software/web/bms-dashboard/`; sumber utama tidak diubah.

## Mulai

```powershell
node tools/serve.mjs
```

Buka `http://127.0.0.1:8790`. Gunakan Chrome/Edge desktop untuk USB serial. Saat pertama dibuka, data selalu DEMO. Aplikasi statis tanpa dependency runtime jaringan; aset berada di `dist/`.

## Fitur

- Logo resmi ARJUNA; tampilan operator dengan navigasi ringkasan, sel, SOC/energi, temperatur, diagnostik, perekaman dan panduan.
- Peta 140 sel, detail, pencarian/filter, grafik; pack voltage/daya hanya jika 140 sel lengkap.
- 10 slot modul × 24 kanal. Delapan modul mengikuti urutan log STM 1A–4A/1B–4B; dua slot cadangan tidak diberi data palsu.
- USB serial 115200/8N1 untuk format InterfaceJOSJIS; HTTP NDJSON stream; polling JSON dengan interval dan batch.
- Logger Worker + IndexedDB, satu baris setiap frame baru, dedup/sequence, export time series terpisah dari snapshot.
- 140 tegangan, 48 tegangan lokal UART, 240 temperatur, current, SOC/SOH dan metadata/status masuk CSV. Kolom lokal mV dipertahankan jika mapping pack belum diketahui.
- Layar 4 Hz terpisah dari logger. Target demo 20/50/100 sampel/s; actual rate ditampilkan, bukan dijamin oleh UI.

## Dokumen

- [Panduan penggunaan](docs/PANDUAN-PENGGUNAAN.md) — juga tersedia di menu Panduan.
- [Kontrak integrasi](docs/INTEGRATION.md) — v1 kompatibilitas, v2 mapping modul dan sequence.
- [Audit source STM32](docs/AUDIT-STM32.md) — fakta kode, bug, mapping, dan hasil build.
- [Evaluasi sebelum/sesudah](docs/EVALUASI-V2.md).
- [Verifikasi](docs/VERIFICATION.md).

## Batas

Kode STM yang dikirim hanya menghasilkan 48 tegangan lokal dan 192 kanal temperatur; belum seluruh 140S. Satuan temperatur °C langsung dikonfirmasi pengguna. Freshness sensor, SOC/SOH dan status contactor/interlock tidak ditambahkan secara palsu oleh browser. Tidak ada command keselamatan yang dikirim HMI.

Perekaman disimpan di browser ini, bagian CSV 16 MiB, batas 512 MiB per sesi. Storage dapat penuh/dihapus dan tab latar belakang dapat ditunda. Untuk logging kendaraan yang harus berjalan tanpa browser, gunakan logger firmware/gateway. Perbaikan firmware yang diidentifikasi belum diterapkan atau diflash; hanya audit dan build salinan dilakukan.

## Uji

```powershell
node tools/check.mjs
node --test tests/model.test.mjs tests/stm-log.test.mjs
node tests/smoke.mjs
```

Smoke test memerlukan server port 8790, Edge dan Playwright. Set `PLAYWRIGHT_PATH` jika lokasi library berbeda. Hasil/screenshot ada di `test-results/` dan tidak dideploy. Native WebMCP belum tersedia pada browser QA; tool opsional read_bms_cells tetap feature-detected.
