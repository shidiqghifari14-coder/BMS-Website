import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import http from 'node:http';
import assert from 'node:assert/strict';
import {makeDemo} from '../dist/model.js';
import {uartFixture} from './fixtures.mjs';
const require=createRequire(import.meta.url);
const {chromium}=require(process.env.PLAYWRIGHT_PATH||'C:/Users/dzakw/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
await fs.mkdir('test-results',{recursive:true});
let streaming=false,sent=0,serial=0,streamStart=0,sourceStartMs=0,clients=new Set();
const gateway=http.createServer((req,res)=>{
 res.setHeader('Access-Control-Allow-Origin','http://127.0.0.1:8790');res.setHeader('Content-Type','application/x-ndjson');res.writeHead(200);res.flushHeaders();
 const f=makeDemo(0);f.sequence=1;f.sourceSessionId='smoke-stream';res.write(JSON.stringify(f)+'\n');
 const timer=setInterval(()=>{if(!streaming||sent>=600)return;const target=Math.min(600,Math.floor((performance.now()-streamStart)/10));while(sent<target){const frame=makeDemo(++serial,'drive',sourceStartMs+serial*10);frame.sequence=serial+1;frame.sourceSessionId='smoke-stream';res.write(JSON.stringify(frame)+'\n');sent++;}},10);
 clients.add(res);req.on('close',()=>{clearInterval(timer);clients.delete(res);});
});
await new Promise(r=>gateway.listen(0,'127.0.0.1',r));const port=gateway.address().port;
const browser=await chromium.launch({channel:'msedge',headless:true});const page=await browser.newPage({viewport:{width:1512,height:1100}});
const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const report={checks:[],consoleErrors:errors};
try{
 await page.goto('http://127.0.0.1:8790');await page.locator('.cell').first().waitFor();assert.equal(await page.locator('.cell').count(),140);
 assert.equal(await page.locator('.brand img').evaluate(i=>i.complete&&i.naturalWidth===610),true);
 await page.locator('[data-cell="140"]').click();await page.getByRole('heading',{name:'C140',exact:true}).waitFor();await page.getByRole('button',{name:'Tutup detail sel'}).click();
 await page.locator('[data-view="cells"]').click();await page.locator('#cellSearch').fill('C087');assert.equal(await page.locator('tbody tr').count(),1);await page.locator('#cellSearch').fill('');await page.locator('#cellFilter').selectOption('balancing');await page.locator('#scenario').selectOption('balance');assert.equal(await page.locator('tbody tr').count(),9);
 await page.locator('[data-view="thermal"]').click();assert.equal(await page.locator('.module-card').count(),10);assert.equal(await page.locator('.temp-card').count(),240);assert.match(await page.locator('.module-card').nth(8).innerText(),/Belum terpasang/);
 await page.locator('#thermalModule').selectOption('8');assert.equal(await page.locator('.module-card').count(),1);await page.locator('#thermalModule').selectOption('all');
 await page.locator('#scenario').selectOption('thermal');assert.equal(await page.locator('.temp-card.fault').count(),1);assert.match(await page.locator('#packStatus').innerText(),/Fault/);
 await page.locator('#scenario').selectOption('offline');await page.waitForTimeout(5400);assert.match(await page.locator('#packStatus').innerText(),/terputus/);
 await page.locator('#scenario').selectOption('drive');await page.waitForTimeout(100);report.checks.push('logos, 140 cells, inspector, filters, 10×24 thermal slots, reserved modules, fault/stale recovery');
 await page.locator('[data-view="guide"]').click();assert.match(await page.locator('.guide').innerText(),/115200/);assert.match(await page.locator('.guide').innerText(),/48 sel lokal/);
 await page.locator('#connectButton').click();await page.locator('#transport').selectOption('stream');await page.locator('#endpoint').fill(`http://127.0.0.1:${port}/stream`);await page.locator('#submitConnection').click();await page.waitForFunction(()=>document.querySelector('#connectionLabel').textContent.includes('LIVE'));
 await page.locator('[data-view="logging"]').click();await page.locator('#sessionName').fill('100Hz stream acceptance');await page.locator('#startRecording').click();await page.waitForFunction(()=>!document.querySelector('#recordRibbon').hidden);
 const started=performance.now();streamStart=started;sourceStartMs=Date.now();streaming=true;while(sent<600)await new Promise(r=>setTimeout(r,100));streaming=false;await page.waitForTimeout(700);await page.locator('#stopRecording').click();await page.waitForFunction(()=>document.querySelector('#recordRibbon').hidden);
 const promise=page.waitForEvent('download');await page.locator('#exportRecording').click();const download=await promise;const csv=await fs.readFile(await download.path(),'utf8');const rows=csv.trim().split('\r\n');const sequences=rows.slice(1).map(r=>Number(r.split(',')[2]));assert.equal(rows.length,601);assert.equal(new Set(sequences).size,600);assert.equal(sequences[0],2);assert.equal(sequences.at(-1),601);assert.equal(Number(rows.at(-1).split(',')[3])-Number(rows[1].split(',')[3]),5990);assert.ok(rows[0].includes('M10_T24_degC'));assert.ok(rows[0].includes('C140_V'));assert.ok(rows.every(r=>!r.includes('NaN')));
 report.recording={sent,recorded:rows.length-1,duplicates:sequences.length-new Set(sequences).size,elapsedSeconds:(performance.now()-started)/1000,sourceTargetHz:100,sourceTimestampSpanMs:5990,sourceRateHz:100};await fs.writeFile('test-results/stream-600.csv',csv);
 await page.reload();await page.locator('[data-view="logging"]').click();await page.locator('#recordedSession option').filter({hasText:'100Hz stream acceptance'}).waitFor({state:'attached'});assert.match(await page.locator('#recordedSession').innerText(),/600 baris/);report.checks.push('600 real HTTP stream frames at 100 Hz target; 600 CSV rows; consecutive unique sequence; persistent reload recovery');
 for(const width of [390,768,1280,1512]){await page.setViewportSize({width,height:1000});for(const v of ['overview','cells','energy','thermal','diagnostics','logging','guide']){await page.locator(`[data-view="${v}"]`).click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`${v} overflow ${width}`);}if(width===390){await page.locator('[data-view="thermal"]').click();await page.screenshot({path:'test-results/v2-mobile.png',fullPage:true});}}
 await page.evaluate(text=>{window.uartOpenOptions=null;const encoder=new TextEncoder();let timer;const fake={readable:null,async open(options){window.uartOpenOptions=options;this.readable=new ReadableStream({start(c){timer=setInterval(()=>c.enqueue(encoder.encode(text)),100);},cancel(){clearInterval(timer);}});},async close(){clearInterval(timer);}};Object.defineProperty(navigator,'serial',{configurable:true,value:{async requestPort(){return fake;}}});},uartFixture());
 await page.locator('#connectButton').click();await page.locator('#transport').selectOption('serial');await page.locator('#submitConnection').click();await page.waitForFunction(()=>document.querySelector('#statusDetail').textContent.includes('Log STM'));
 assert.equal(await page.evaluate(()=>window.uartOpenOptions.baudRate),115200);assert.match(await page.locator('#packVoltage').innerText(),/—/);assert.match(await page.locator('#packCurrent').innerText(),/12.3/);await page.locator('[data-view="thermal"]').click();assert.match(await page.locator('.module-card').nth(7).innerText(),/4B/);assert.equal(await page.locator('.module-card').nth(7).locator('.temp-card').last().locator('strong').innerText(),'50.0');
 await page.locator('#connectButton').click();await page.locator('#demoButton').click();report.checks.push('USB Serial API shim: 115200 8N1; complete legacy STM cycle; current sign; correct module 4B T24; no assumed pack mapping');
 await page.locator('[data-view="logging"]').click();await page.screenshot({path:'test-results/v2-logging.png',fullPage:true});report.checks.push('all 7 views at 390/768/1280/1512 pixels; no horizontal page overflow');
 assert.deepEqual(errors,[]);report.passed=true;await fs.writeFile('test-results/smoke-v2-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();for(const c of clients)c.end();gateway.close();}
