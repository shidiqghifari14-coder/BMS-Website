import test from 'node:test';
import assert from 'node:assert/strict';
import {makeDemo,validateFrame,stats,toCsv} from '../dist/model.js';
const now=Date.now();
test('140 unique cells, exact pack sum, power units and independent frame',()=>{
 const f=makeDemo(0,'drive',now),v=validateFrame(f,now),s=stats(v);
 assert.equal(s.valid,140);assert.equal(new Set(f.cells.map(c=>c.id)).size,140);
 assert.equal(s.pack,f.cells.reduce((sum,c)=>sum+c.voltageV,0));
 assert.equal(s.power,s.pack*f.currentA/1000);v.cells[0].voltageV=0;assert.notEqual(f.cells[0].voltageV,0);
});
test('missing measurement does not create a partial pack voltage or guessed SOC',()=>{
 const f=makeDemo(0,'drive',now);f.cells[20].voltageV=null;f.socPct=null;f.sohPct=null;f.remainingKwh=null;
 const v=validateFrame(f,now),s=stats(v);assert.equal(s.valid,139);assert.equal(s.pack,null);assert.equal(s.power,null);assert.equal(v.socPct,null);
 f.cells.forEach(c=>c.voltageV=null);f.temperatures.forEach(t=>t.celsius=null);const all=stats(validateFrame(f,now));assert.equal(all.low,null);assert.equal(all.delta,null);assert.equal(all.maxTemp,null);
});
test('rejects short, duplicate, NaN, string numbers and invalid statuses',()=>{
 for(const change of [f=>f.cells.pop(),f=>f.cells[1].id=1,f=>f.cells[0].voltageV=NaN,f=>f.currentA='32',f=>f.socPct=101,f=>f.cells[0].status='healthy',f=>f.system.contactor='energized',f=>f.temperatures[1].id=1]){const f=makeDemo(0,'drive',now);change(f);assert.throws(()=>validateFrame(f,now));}
});
test('rejects stale, future, and incompatible telemetry',()=>{
 for(const change of [f=>f.timestampMs=now-5001,f=>f.timestampMs=now+2001,f=>f.schema='legacy']){const f=makeDemo(0,'drive',now);change(f);assert.throws(()=>validateFrame(f,now));}
});
test('demo scenarios remain explicitly simulated and flag correct sensor',()=>{
 const imbalance=makeDemo(0,'imbalance',now);assert.equal(stats(imbalance).low.id,87);assert.equal(imbalance.cells[86].status,'warning');
 const thermal=makeDemo(0,'thermal',now);assert.equal(thermal.system.contactor,'open');assert.equal(thermal.temperatures[12].status,'fault');assert.equal(thermal.currentA,0);
 assert.equal(stats(makeDemo(0,'balance',now)).balancing,9);
});
test('CSV exports all cells with source, stale state and unambiguous units',()=>{
 const csv=toCsv(makeDemo(0,'drive',now),'demo',true),lines=csv.split('\r\n');assert.equal(lines.length,141);assert.match(lines[0],/voltage_V/);assert.match(lines[140],/"demo","stale"/);assert.match(lines[140],/"140"/);
});
