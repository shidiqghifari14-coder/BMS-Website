import {MODULE_LABELS} from '../dist/stm-log.js';
export function uartFixture(){
 let s='Current : -12.34\n';
 for(let m=0;m<4;m++)s+=`VOLTAGE --- ${m+1}A \n`+Array.from({length:12},(_,i)=>`@${3700+m*12+i},${i%6===5?'@':''}`).join('')+(m===3?'#\n\r':'\n');
 for(let m=0;m<8;m++)s+=(m?'--':'')+`TEMP DATA --- ${MODULE_LABELS[m]} \n`+Array.from({length:24},(_,i)=>`${20+m+i} -`).join('')+(m===7?'#\n\r':'\n');
 return s;
}
